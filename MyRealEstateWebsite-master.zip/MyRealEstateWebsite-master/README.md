## Available Scripts

In the project directory, you can run:

### `npm start`
Runs the app in the development mode.

### `cd backend`
### `node server`
Runs the backend in the development mode.

![development](https://user-images.githubusercontent.com/65255043/175781163-4c175747-92cf-4029-b6da-6e630ac4f3e9.PNG)

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

![Homepage](https://user-images.githubusercontent.com/65255043/175781171-ed7a282f-a956-4ba5-bbd7-6f451e7cdf2d.PNG)

The page will reload if you make edits.\
You will also see any lint errors in the console.
